<?php
$type='Type1';
$name='IrisUPCBold';
$desc=array('Ascent'=>491,'Descent'=>-176,'CapHeight'=>445,'Flags'=>32,'FontBBox'=>'[-372 -204 875 849]','ItalicAngle'=>0,'StemV'=>120);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>220,'!'=>266,'"'=>308,'#'=>471,'$'=>440,'%'=>507,'&'=>452,'\''=>219,'('=>318,')'=>318,'*'=>327,'+'=>401,
	','=>212,'-'=>401,'.'=>177,'/'=>350,'0'=>460,'1'=>460,'2'=>460,'3'=>460,'4'=>460,'5'=>460,'6'=>460,'7'=>460,'8'=>460,'9'=>460,':'=>212,';'=>212,'<'=>343,'='=>401,'>'=>343,'?'=>440,'@'=>487,'A'=>434,
	'B'=>397,'C'=>434,'D'=>506,'E'=>325,'F'=>325,'G'=>506,'H'=>506,'I'=>216,'J'=>216,'K'=>397,'L'=>325,'M'=>578,'N'=>506,'O'=>541,'P'=>361,'Q'=>541,'R'=>397,'S'=>325,'T'=>361,'U'=>506,'V'=>434,'W'=>650,
	'X'=>397,'Y'=>397,'Z'=>397,'['=>216,'\\'=>338,']'=>216,'^'=>394,'_'=>325,'`'=>216,'a'=>325,'b'=>361,'c'=>325,'d'=>361,'e'=>325,'f'=>205,'g'=>325,'h'=>361,'i'=>181,'j'=>181,'k'=>325,'l'=>181,'m'=>541,
	'n'=>361,'o'=>361,'p'=>361,'q'=>361,'r'=>253,'s'=>253,'t'=>216,'u'=>361,'v'=>325,'w'=>506,'x'=>325,'y'=>325,'z'=>325,'{'=>216,'|'=>394,'}'=>216,'~'=>394,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>220,chr(161)=>431,chr(162)=>435,chr(163)=>458,chr(164)=>446,chr(165)=>446,chr(166)=>482,chr(167)=>312,chr(168)=>413,chr(169)=>472,chr(170)=>458,chr(171)=>481,chr(172)=>631,chr(173)=>606,chr(174)=>444,chr(175)=>443,
	chr(176)=>396,chr(177)=>515,chr(178)=>618,chr(179)=>601,chr(180)=>445,chr(181)=>445,chr(182)=>426,chr(183)=>438,chr(184)=>388,chr(185)=>458,chr(186)=>438,chr(187)=>443,chr(188)=>417,chr(189)=>420,chr(190)=>469,chr(191)=>469,chr(192)=>440,chr(193)=>452,chr(194)=>420,chr(195)=>330,chr(196)=>422,chr(197)=>430,
	chr(198)=>443,chr(199)=>343,chr(200)=>446,chr(201)=>457,chr(202)=>429,chr(203)=>444,chr(204)=>477,chr(205)=>413,chr(206)=>411,chr(207)=>359,chr(208)=>312,chr(209)=>0,chr(210)=>333,chr(211)=>327,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>397,chr(224)=>233,chr(225)=>419,chr(226)=>273,chr(227)=>279,chr(228)=>310,chr(229)=>318,chr(230)=>527,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>446,chr(241)=>448,
	chr(242)=>499,chr(243)=>444,chr(244)=>475,chr(245)=>482,chr(246)=>469,chr(247)=>564,chr(248)=>478,chr(249)=>516,chr(250)=>474,chr(251)=>896,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='irisb.z';
$size1=5635;
$size2=31940;
?>
