<?php
$type='Type1';
$name='PLETom';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>472,'Flags'=>32,'FontBBox'=>'[-483 -295 731 889]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>142,'!'=>186,'"'=>166,'#'=>431,'$'=>359,'%'=>283,'&'=>347,'\''=>114,'('=>188,')'=>211,'*'=>345,'+'=>283,
	','=>121,'-'=>381,'.'=>131,'/'=>370,'0'=>369,'1'=>145,'2'=>353,'3'=>368,'4'=>289,'5'=>355,'6'=>280,'7'=>304,'8'=>269,'9'=>338,':'=>173,';'=>152,'<'=>266,'='=>477,'>'=>277,'?'=>298,'@'=>388,'A'=>424,
	'B'=>492,'C'=>512,'D'=>608,'E'=>411,'F'=>356,'G'=>606,'H'=>367,'I'=>444,'J'=>516,'K'=>368,'L'=>554,'M'=>379,'N'=>490,'O'=>524,'P'=>442,'Q'=>551,'R'=>402,'S'=>466,'T'=>484,'U'=>379,'V'=>453,'W'=>464,
	'X'=>424,'Y'=>295,'Z'=>489,'['=>281,'\\'=>405,']'=>325,'^'=>202,'_'=>321,'`'=>103,'a'=>390,'b'=>355,'c'=>421,'d'=>425,'e'=>298,'f'=>316,'g'=>244,'h'=>312,'i'=>146,'j'=>271,'k'=>227,'l'=>130,'m'=>425,
	'n'=>284,'o'=>287,'p'=>332,'q'=>288,'r'=>267,'s'=>284,'t'=>284,'u'=>312,'v'=>317,'w'=>387,'x'=>248,'y'=>225,'z'=>281,'{'=>161,'|'=>98,'}'=>160,'~'=>272,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>142,chr(161)=>304,chr(162)=>231,chr(163)=>305,chr(164)=>322,chr(165)=>364,chr(166)=>388,chr(167)=>339,chr(168)=>378,chr(169)=>406,chr(170)=>248,chr(171)=>282,chr(172)=>403,chr(173)=>325,chr(174)=>313,chr(175)=>317,
	chr(176)=>307,chr(177)=>412,chr(178)=>553,chr(179)=>412,chr(180)=>376,chr(181)=>392,chr(182)=>325,chr(183)=>388,chr(184)=>268,chr(185)=>312,chr(186)=>354,chr(187)=>350,chr(188)=>457,chr(189)=>406,chr(190)=>435,chr(191)=>443,chr(192)=>316,chr(193)=>410,chr(194)=>331,chr(195)=>241,chr(196)=>264,chr(197)=>337,
	chr(198)=>326,chr(199)=>332,chr(200)=>329,chr(201)=>428,chr(202)=>300,chr(203)=>362,chr(204)=>362,chr(205)=>309,chr(206)=>319,chr(207)=>322,chr(208)=>188,chr(209)=>0,chr(210)=>167,chr(211)=>190,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>402,chr(224)=>150,chr(225)=>259,chr(226)=>198,chr(227)=>191,chr(228)=>206,chr(229)=>188,chr(230)=>277,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>259,chr(240)=>366,chr(241)=>366,
	chr(242)=>380,chr(243)=>333,chr(244)=>410,chr(245)=>382,chr(246)=>374,chr(247)=>597,chr(248)=>448,chr(249)=>409,chr(250)=>378,chr(251)=>655,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='pletom.z';
$size1=6064;
$size2=33156;
?>
